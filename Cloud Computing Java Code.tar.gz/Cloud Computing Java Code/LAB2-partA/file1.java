import javax.swing.*;
import java.io.*;
public class file1
{
public static void main(String []args)throws IOException
{
FileWriter ryt=new FileWriter("alpe.jacl");
BufferedWriter out=new BufferedWriter(ryt);
JTextField wsName = new JTextField();
JTextField sName = new JTextField();
JTextField cName = new JTextField();
Object[] message = {    "Web Server Name:", wsName,"Server Name:", sName,"Cluster Name:", cName};
int answer = JOptionPane.showConfirmDialog(    null, message, "Enter values", JOptionPane.OK_CANCEL_OPTION);
if (answer == JOptionPane.OK_OPTION){    String webserver = wsName.getText();
String server = sName.getText();
String cluster = cName.getText();
out.write("set webservername " +wsName.getText()+"\n");
out.write("set ClusterName " +cName.getText()+"\n");
out.write("set ServerName " +sName.getText()+"\n");
out.close();
}
}}
