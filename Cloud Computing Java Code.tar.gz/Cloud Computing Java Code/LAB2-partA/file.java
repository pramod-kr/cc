
import javax.swing.*;
import java.io.*;
public class file
{
public static void main(String []args)throws IOException
{
FileWriter ryt=new FileWriter("alpe.jacl");
BufferedWriter out=new BufferedWriter(ryt);
String name=JOptionPane.showInputDialog("Enter webserverName");
out.write("set webservername " +name);
String name1=JOptionPane.showInputDialog("Enter serverName");
out.write("set serverName " +name1);
String name2=JOptionPane.showInputDialog("Enter ClusterName");
out.write("set ClusterName " +name2);
out.write("\r\nThis the simple txt file that you created!");
out.close();
}}
